<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-scroller">
    <div class="main-panel">

        <header id="home" class="jumbotron banner bg-dark">
            <h2 class="section-header text-uppercase display-4 text-light">Agriculture </h2>
            <h5 class="text-white">Au Royaume Emerkhammaat nous optons pour l'agriculture</h5>
        </header>

        <div class="py-2">

            <p>

            
            </p>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/princethierrycaviarosfilms/Desktop/kingdom_new/resources/views/pages/agriculture.blade.php ENDPATH**/ ?>