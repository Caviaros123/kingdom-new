<?php $__env->startSection('content'); ?>

<div class="container-scroller">
    <header id="home" class="jumbotron banner bg-dark">
        <h2 class="section-header text-uppercase display-4 text-light">Nos produits</h2>
    </header>

    <div class="main-panel">

        <div class="container">
            <h3>
                Vous trouvez ici nos produits divers
            </h3>


            <div class="row">

                <?php $__empty_1 = true; $__currentLoopData = App\Product::where('category', 'agro')->paginate(12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <div class="col-lg-3 card col-md-6 m-3 m-0 p-0">
                    <a href="/show/<?php echo e($product->id); ?>">
                        <div class=" card-body m-0 p-0">
                            <div class="pi-pic card-header m-0 p-0" data-setbg="">
                                <img src="<?php echo e(Voyager::image($product->image, 'small')); ?>" class="img-fluid" alt="<?php echo e($product->name); ?>">

                            </div>
                            <div class="pi-text p-3">
                                <a href="#" class="heart-icon"><span class="icon_heart_alt"></span></a>
                                <div class="pt-price"><?php echo e($product->prix); ?> FCFA <span hidden>/month</span></div>
                                <h5><a href="show/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a></h5>
                                <p><span class="icon_pin_alt"></span> <?php echo e($product->details); ?></p>
                                <?php if($product->options != null): ?>
                                <ul>

                                    
                                    <!-- <li><i class="fa fa-bathtub"></i> 03</li>
                                    <li><i class="fa fa-bed"></i> 05</li>
                                    <li><i class="fa fa-automobile"></i> 01</li> -->

                                    <span class="text-danger ">Aucune option disponible</span>

                                </ul>
                                <?php endif; ?>

                            </div>
                            <!-- <div class="label">A <?php echo e(date($product->created_at)); ?></div> -->

                        </div>
                    </a>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-md-12 offset-md-12 padding-y    text-center">
                    <p class="m-3 text-light alert alert-danger b display-3">AUCUN ARTICLE EN VENTE POUR LE MOMENT, REVENEZ PLUS TARD !!</p>

                </div>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/princethierrycaviarosfilms/Desktop/kingdom_new/resources/views/pages/product.blade.php ENDPATH**/ ?>