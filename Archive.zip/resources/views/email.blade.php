<h2 style="color: purple">Nouveau message,</h2>
<h4 style="color: purple">De: {{ $name }}</h4>
<hr>
Contenu du Message: <br><h3>{{ $form_message }}</h3><br>
<hr>
Informations de l'utilisateur:<br><br>
Nom: <strong>{{ $name }}</strong><br>
Email: <strong>{{ $email }}</strong><br>
Telephone: <strong>{{ $phone }}</strong><br>
Sujet: <strong>{{ $subject }}</strong><br>

Fin<br>
<strong style="color: purple">Message envoyé par un utilisateur depuis le site www.emerkhammaat.com</strong>